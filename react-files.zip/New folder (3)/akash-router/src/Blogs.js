const Blogs=()=>{
    return<h1>blogs articles</h1>;
};
export default Blogs;