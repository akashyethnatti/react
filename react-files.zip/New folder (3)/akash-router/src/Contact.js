const Contact=()=>{
    
    return<h1>contact akash</h1>;
};

export default Contact;